<?php

use Symfony\Component\Routing\Matcher\Dumper\PhpMatcherTrait;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcApp_KernelDevDebugContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    use PhpMatcherTrait;

    public function __construct(RequestContext $context)
    {
        $this->context = $context;
        $this->staticRoutes = array(
            '/mentorStudenti' => array(array(array('_route' => 'mentor_Studenti', '_controller' => 'App\\Controller\\MentorController::mentorStudenti'), null, null, null, true, false, null)),
            '/mentorPredmeti' => array(array(array('_route' => 'mentor_Predmeti', '_controller' => 'App\\Controller\\MentorController::mentorPredmeti'), null, null, null, true, false, null)),
            '/mentorPredmeti/novi' => array(array(array('_route' => 'novi_predmet', '_controller' => 'App\\Controller\\MentorController::noviPredmet'), null, null, null, true, false, null)),
            '/register' => array(array(array('_route' => 'app_register', '_controller' => 'App\\Controller\\RegistrationController::register'), null, null, null, false, false, null)),
            '/login' => array(
                array(array('_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'), null, null, null, true, false, null),
                array(array('_route' => 'app_logout'), null, null, null, true, false, null),
            ),
            '/student' => array(array(array('_route' => 'student', '_controller' => 'App\\Controller\\StudentController::studentUpis'), null, null, null, true, false, null)),
            '/_profiler' => array(array(array('_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'), null, null, null, true, false, null)),
            '/_profiler/search' => array(array(array('_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'), null, null, null, false, false, null)),
            '/_profiler/search_bar' => array(array(array('_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'), null, null, null, false, false, null)),
            '/_profiler/phpinfo' => array(array(array('_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'), null, null, null, false, false, null)),
            '/_profiler/open' => array(array(array('_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'), null, null, null, false, false, null)),
        );
        $this->regexpList = array(
            0 => '{^(?'
                    .'|/mentor(?'
                        .'|Predmeti/(?'
                            .'|detalji/([^/]++)(*:45)'
                            .'|uredi/([^/]++)(*:66)'
                        .')'
                        .'|Studenti/(?'
                            .'|student/([^/]++)(*:102)'
                            .'|([^/]++)/tmp(?'
                                .'|/([^/]++)(*:134)'
                                .'|p/([^/]++)(*:152)'
                                .'|i/([^/]++)(*:170)'
                            .')'
                        .')'
                    .')'
                    .'|/student/([^/]++)/tmp(?'
                        .'|/([^/]++)(*:214)'
                        .'|p/([^/]++)(*:232)'
                        .'|i/([^/]++)(*:250)'
                    .')'
                    .'|/_(?'
                        .'|error/(\\d+)(?:\\.([^/]++))?(*:290)'
                        .'|wdt/([^/]++)(*:310)'
                        .'|profiler/([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:356)'
                                .'|router(*:370)'
                                .'|exception(?'
                                    .'|(*:390)'
                                    .'|\\.css(*:403)'
                                .')'
                            .')'
                            .'|(*:413)'
                        .')'
                    .')'
                .')/?$}sDu',
        );
        $this->dynamicRoutes = array(
            45 => array(array(array('_route' => 'predmet_detalji', '_controller' => 'App\\Controller\\MentorController::detalji'), array('id'), null, null, false, true, null)),
            66 => array(array(array('_route' => 'predmet_uredi', '_controller' => 'App\\Controller\\MentorController::uredi'), array('id'), null, null, false, true, null)),
            102 => array(array(array('_route' => 'mentor_student', '_controller' => 'App\\Controller\\MentorController::student'), array('id'), null, null, false, true, null)),
            134 => array(array(array('_route' => 'mentor_tmp', '_controller' => 'App\\Controller\\MentorController::tmp'), array('id', 'pid'), null, null, false, true, null)),
            152 => array(array(array('_route' => 'mentor_tmpp', '_controller' => 'App\\Controller\\MentorController::tmpp'), array('id', 'uid'), null, null, false, true, null)),
            170 => array(array(array('_route' => 'mentor_tmpi', '_controller' => 'App\\Controller\\MentorController::tmpi'), array('id', 'uid'), null, null, false, true, null)),
            214 => array(array(array('_route' => 'student_tmp', '_controller' => 'App\\Controller\\StudentController::tmp'), array('id', 'pid'), null, null, false, true, null)),
            232 => array(array(array('_route' => 'student_tmpp', '_controller' => 'App\\Controller\\StudentController::tmpp'), array('id', 'uid'), null, null, false, true, null)),
            250 => array(array(array('_route' => 'student_tmpi', '_controller' => 'App\\Controller\\StudentController::tmpi'), array('id', 'uid'), null, null, false, true, null)),
            290 => array(array(array('_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'), array('code', '_format'), null, null, false, true, null)),
            310 => array(array(array('_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'), array('token'), null, null, false, true, null)),
            356 => array(array(array('_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'), array('token'), null, null, false, false, null)),
            370 => array(array(array('_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'), array('token'), null, null, false, false, null)),
            390 => array(array(array('_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception::showAction'), array('token'), null, null, false, false, null)),
            403 => array(array(array('_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception::cssAction'), array('token'), null, null, false, false, null)),
            413 => array(array(array('_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'), array('token'), null, null, false, true, null)),
        );
    }
}

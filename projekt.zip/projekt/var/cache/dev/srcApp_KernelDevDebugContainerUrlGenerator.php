<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcApp_KernelDevDebugContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;
    private $defaultLocale;

    public function __construct(RequestContext $context, LoggerInterface $logger = null, string $defaultLocale = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        $this->defaultLocale = $defaultLocale;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        'mentor_Studenti' => array(array(), array('_controller' => 'App\\Controller\\MentorController::mentorStudenti'), array(), array(array('text', '/mentorStudenti/')), array(), array()),
        'mentor_Predmeti' => array(array(), array('_controller' => 'App\\Controller\\MentorController::mentorPredmeti'), array(), array(array('text', '/mentorPredmeti/')), array(), array()),
        'novi_predmet' => array(array(), array('_controller' => 'App\\Controller\\MentorController::noviPredmet'), array(), array(array('text', '/mentorPredmeti/novi/')), array(), array()),
        'predmet_detalji' => array(array('id'), array('_controller' => 'App\\Controller\\MentorController::detalji'), array(), array(array('variable', '/', '[^/]++', 'id', true), array('text', '/mentorPredmeti/detalji')), array(), array()),
        'predmet_uredi' => array(array('id'), array('_controller' => 'App\\Controller\\MentorController::uredi'), array(), array(array('variable', '/', '[^/]++', 'id', true), array('text', '/mentorPredmeti/uredi')), array(), array()),
        'mentor_student' => array(array('id'), array('_controller' => 'App\\Controller\\MentorController::student'), array(), array(array('variable', '/', '[^/]++', 'id', true), array('text', '/mentorStudenti/student')), array(), array()),
        'mentor_tmp' => array(array('id', 'pid'), array('_controller' => 'App\\Controller\\MentorController::tmp'), array(), array(array('variable', '/', '[^/]++', 'pid', true), array('text', '/tmp'), array('variable', '/', '[^/]++', 'id', true), array('text', '/mentorStudenti')), array(), array()),
        'mentor_tmpp' => array(array('id', 'uid'), array('_controller' => 'App\\Controller\\MentorController::tmpp'), array(), array(array('variable', '/', '[^/]++', 'uid', true), array('text', '/tmpp'), array('variable', '/', '[^/]++', 'id', true), array('text', '/mentorStudenti')), array(), array()),
        'mentor_tmpi' => array(array('id', 'uid'), array('_controller' => 'App\\Controller\\MentorController::tmpi'), array(), array(array('variable', '/', '[^/]++', 'uid', true), array('text', '/tmpi'), array('variable', '/', '[^/]++', 'id', true), array('text', '/mentorStudenti')), array(), array()),
        'app_register' => array(array(), array('_controller' => 'App\\Controller\\RegistrationController::register'), array(), array(array('text', '/register')), array(), array()),
        'app_login' => array(array(), array('_controller' => 'App\\Controller\\SecurityController::login'), array(), array(array('text', '/login/')), array(), array()),
        'student' => array(array(), array('_controller' => 'App\\Controller\\StudentController::studentUpis'), array(), array(array('text', '/student/')), array(), array()),
        'student_tmp' => array(array('id', 'pid'), array('_controller' => 'App\\Controller\\StudentController::tmp'), array(), array(array('variable', '/', '[^/]++', 'pid', true), array('text', '/tmp'), array('variable', '/', '[^/]++', 'id', true), array('text', '/student')), array(), array()),
        'student_tmpp' => array(array('id', 'uid'), array('_controller' => 'App\\Controller\\StudentController::tmpp'), array(), array(array('variable', '/', '[^/]++', 'uid', true), array('text', '/tmpp'), array('variable', '/', '[^/]++', 'id', true), array('text', '/student')), array(), array()),
        'student_tmpi' => array(array('id', 'uid'), array('_controller' => 'App\\Controller\\StudentController::tmpi'), array(), array(array('variable', '/', '[^/]++', 'uid', true), array('text', '/tmpi'), array('variable', '/', '[^/]++', 'id', true), array('text', '/student')), array(), array()),
        '_twig_error_test' => array(array('code', '_format'), array('_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'), array('code' => '\\d+'), array(array('variable', '.', '[^/]++', '_format', true), array('variable', '/', '\\d+', 'code', true), array('text', '/_error')), array(), array()),
        '_wdt' => array(array('token'), array('_controller' => 'web_profiler.controller.profiler::toolbarAction'), array(), array(array('variable', '/', '[^/]++', 'token', true), array('text', '/_wdt')), array(), array()),
        '_profiler_home' => array(array(), array('_controller' => 'web_profiler.controller.profiler::homeAction'), array(), array(array('text', '/_profiler/')), array(), array()),
        '_profiler_search' => array(array(), array('_controller' => 'web_profiler.controller.profiler::searchAction'), array(), array(array('text', '/_profiler/search')), array(), array()),
        '_profiler_search_bar' => array(array(), array('_controller' => 'web_profiler.controller.profiler::searchBarAction'), array(), array(array('text', '/_profiler/search_bar')), array(), array()),
        '_profiler_phpinfo' => array(array(), array('_controller' => 'web_profiler.controller.profiler::phpinfoAction'), array(), array(array('text', '/_profiler/phpinfo')), array(), array()),
        '_profiler_search_results' => array(array('token'), array('_controller' => 'web_profiler.controller.profiler::searchResultsAction'), array(), array(array('text', '/search/results'), array('variable', '/', '[^/]++', 'token', true), array('text', '/_profiler')), array(), array()),
        '_profiler_open_file' => array(array(), array('_controller' => 'web_profiler.controller.profiler::openAction'), array(), array(array('text', '/_profiler/open')), array(), array()),
        '_profiler' => array(array('token'), array('_controller' => 'web_profiler.controller.profiler::panelAction'), array(), array(array('variable', '/', '[^/]++', 'token', true), array('text', '/_profiler')), array(), array()),
        '_profiler_router' => array(array('token'), array('_controller' => 'web_profiler.controller.router::panelAction'), array(), array(array('text', '/router'), array('variable', '/', '[^/]++', 'token', true), array('text', '/_profiler')), array(), array()),
        '_profiler_exception' => array(array('token'), array('_controller' => 'web_profiler.controller.exception::showAction'), array(), array(array('text', '/exception'), array('variable', '/', '[^/]++', 'token', true), array('text', '/_profiler')), array(), array()),
        '_profiler_exception_css' => array(array('token'), array('_controller' => 'web_profiler.controller.exception::cssAction'), array(), array(array('text', '/exception.css'), array('variable', '/', '[^/]++', 'token', true), array('text', '/_profiler')), array(), array()),
        'app_logout' => array(array(), array(), array(), array(array('text', '/login/')), array(), array()),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        $locale = $parameters['_locale']
            ?? $this->context->getParameter('_locale')
            ?: $this->defaultLocale;

        if (null !== $locale && null !== $name) {
            do {
                if ((self::$declaredRoutes[$name.'.'.$locale][1]['_canonical_route'] ?? null) === $name) {
                    unset($parameters['_locale']);
                    $name .= '.'.$locale;
                    break;
                }
            } while (false !== $locale = strstr($locale, '_', true));
        }

        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}

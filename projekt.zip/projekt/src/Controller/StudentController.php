<?php

namespace App\Controller;

use App\Entity\Korisnici;
use App\Entity\Predmeti;
use App\Entity\Upisi;
use App\Form\PredmetiFormType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Intl\Exception\NotImplementedException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;


class StudentController extends AbstractController{

     /**
     * @Route("/student/", name="student")
     */
    public function studentUpis()
    {
        $doctrine = $this->getDoctrine();
        $repository = $doctrine->getRepository(Upisi::class);

        $student = $this->getUser();

        $predmet = $this
        ->getDoctrine()
        ->getRepository(Predmeti::class)
        ->findAll()
    ;
    $upisaniPredmeti = $repository->findCoursesAssignedToStudent($student);

        $upisaniPredmeti = array_map(function($row){
            return $row->getPredmetId();
        }, $upisaniPredmeti);
    
    $upisanitab = $repository->findCoursesAssignedToStudent($student);

        return $this->render("student/index.html.twig", [
        "student" => $student,
        "predmet" => $predmet,
        "upisaniPredmeti" => $upisaniPredmeti,
        "upisanitab" => $upisanitab,
        ]);
    }

     /**
     * @Route("/student/{id}/tmp/{pid}", name="student_tmp")
     */

    public function tmp($id,$pid)
    {
       $doctine = $this->getDoctrine();

       $student = $doctine->getRepository(Korisnici::class)->find($id);
       $predmet = $doctine->getRepository(Predmeti::class)->find($pid);

       $upis = new Upisi();

       $upis
           ->setStudentId($student)
           ->setPredmetId($predmet)
           ->setStatus('enrolled')
       ;

       $u = $doctine->getManager();
       $u->persist($upis);
       $u->flush();

       return $this->redirectToRoute('student');

    }

    /**
    * @Route("/student/{id}/tmpp/{uid}", name="student_tmpp")
    */

   public function tmpp($id,$uid)
   {
      $doctine = $this->getDoctrine();

      $upis = $doctine->getRepository(Upisi::class)->find($uid);

      $upis
          ->setStatus('passed')
      ;

      $u = $doctine->getManager();
      $u->persist($upis);
      $u->flush();

      return $this->redirectToRoute('student');

   }

   /**
    * @Route("/student/{id}/tmpi/{uid}", name="student_tmpi")
    */

   public function tmpi($id,$uid)
   {
      $doctine = $this->getDoctrine();

      $upis = $doctine->getRepository(Upisi::class)->find($uid);

      $u = $doctine->getManager();
      $u->remove($upis);
      $u->flush();

      return $this->redirectToRoute('student');
   }
}
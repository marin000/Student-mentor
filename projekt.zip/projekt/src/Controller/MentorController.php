<?php

namespace App\Controller;

use App\Entity\Korisnici;
use App\Entity\Predmeti;
use App\Entity\Upisi;
use App\Form\PredmetiFormType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Intl\Exception\NotImplementedException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;


class MentorController extends AbstractController{

     /**
     * @Route("/mentorStudenti/", name="mentor_Studenti")
     */
    public function mentorStudenti()
    {
        $mentorSt = $this->getDoctrine()
            ->getRepository(Korisnici::class)
            ->findAll();
             return $this->render("mentor/studenti.html.twig", [
            "mentorSt" => $mentorSt
        ]);
    }

    /**
     * @Route("/mentorPredmeti/",name="mentor_Predmeti")
     */
    public function mentorPredmeti()
    {
        $mentorPd = $this->getDoctrine()
            ->getRepository(Predmeti::class)
            ->findAll();
            return $this->render("mentor/predmeti.html.twig",[
                "mentorPd" => $mentorPd
            ]);
    }

    /**
     * @Route("/mentorPredmeti/novi/",name="novi_predmet")
     */
    public function noviPredmet(Request $request)
    {
        $predmet = new Predmeti();
        $form = $this->createForm(PredmetiFormType::class, $predmet);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            if (isset($_POST['predmeti_form_izborni'])) {
                $predmet->setIzborni(array("da"));
              } else {
                $predmet->setIzborni(array("ne"));
              }

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($predmet);
            $entityManager->flush();

            return $this->redirectToRoute('mentor_Predmeti');
        }
        return $this->render("mentor/noviPredmet.html.twig", [
            'form' => $form->createView(),
        ]);

    }

      /**
      * @Route("/mentorPredmeti/detalji/{id}",name="predmet_detalji")
     */
    public function detalji(Request $request, $id)
    {
        $predmet = $this
            ->getDoctrine()
            ->getRepository(Predmeti::class)
            ->find($id)
        ;

        return $this->render("mentor/detaljiPredmet.html.twig", [
            "predmet" => $predmet,
        ]);
    }

     /**
     * @Route("/mentorPredmeti/uredi/{id}", name="predmet_uredi")
     */
    public function uredi(Request $request, $id)
    {
        $predmet = $this
            ->getDoctrine()
            ->getRepository(Predmeti::class)
            ->find($id)
        ;

        $form = $this->createForm(PredmetiFormType::class, $predmet);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            if (isset($_POST['predmeti_form_izborni'])) {
                $predmet->setIzborni(array("da"));
            } else {
                $predmet->setIzborni(array("ne"));
              }

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($predmet);
            $entityManager->flush();

            return $this->redirectToRoute('mentor_Predmeti');
        }

        return $this->render("mentor/urediPredmet.html.twig", [
            "predmet" => $predmet,
            "form" => $form->createView()
        ]);
    }

    /**
     * @Route("/mentorStudenti/student/{id}", name="mentor_student")
     */
    public function student(Request $request, $id)
    {
        /* $student = $this
        ->getDoctrine()
        ->getRepository(Korisnici::class)
        ->find($id)
    ;*/
        $doctrine = $this->getDoctrine();
        $repository = $doctrine->getRepository(Upisi::class);

        $student = $doctrine->getRepository(Korisnici::class)->find($id);

        $predmet = $this
        ->getDoctrine()
        ->getRepository(Predmeti::class)
        ->findAll()
    ;
    $upisaniPredmeti = $repository->findCoursesAssignedToStudent($student);

        $upisaniPredmeti = array_map(function($row){
            return $row->getPredmetId();
        }, $upisaniPredmeti);
    
    $upisanitab = $repository->findCoursesAssignedToStudent($student);

    return $this->render("mentor/student.html.twig", [
        "student" => $student,
        "predmet" => $predmet,
        "upisaniPredmeti" => $upisaniPredmeti,
        "upisanitab" => $upisanitab,
    ]);

    }

    /**
     * @Route("/mentorStudenti/{id}/tmp/{pid}", name="mentor_tmp")
     */

     public function tmp($id,$pid)
     {
        $doctine = $this->getDoctrine();

        $student = $doctine->getRepository(Korisnici::class)->find($id);
        $predmet = $doctine->getRepository(Predmeti::class)->find($pid);

        $upis = new Upisi();

        $upis
            ->setStudentId($student)
            ->setPredmetId($predmet)
            ->setStatus('enrolled')
        ;

        $u = $doctine->getManager();
        $u->persist($upis);
        $u->flush();

        return $this->redirectToRoute('mentor_student', ['id' => $id]);

     }

     /**
     * @Route("/mentorStudenti/{id}/tmpp/{uid}", name="mentor_tmpp")
     */

    public function tmpp($id,$uid)
    {
       $doctine = $this->getDoctrine();

       $upis = $doctine->getRepository(Upisi::class)->find($uid);

       $upis
           ->setStatus('passed')
       ;

       $u = $doctine->getManager();
       $u->persist($upis);
       $u->flush();

       return $this->redirectToRoute('mentor_student', ['id' => $id]);

    }

    /**
     * @Route("/mentorStudenti/{id}/tmpi/{uid}", name="mentor_tmpi")
     */

    public function tmpi($id,$uid)
    {
       $doctine = $this->getDoctrine();

       $upis = $doctine->getRepository(Upisi::class)->find($uid);

       $u = $doctine->getManager();
       $u->remove($upis);
       $u->flush();

       return $this->redirectToRoute('mentor_student', ['id' => $id]);

    }
}
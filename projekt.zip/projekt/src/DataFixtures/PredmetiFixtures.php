<?php

namespace App\DataFixtures;
use App\Entity\Predmeti;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class PredmetiFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $predmet = new Predmeti();
        $predmet->setIme("Uvod u programiranje");
        $predmet->setKod("SIT010");
        $predmet->setProgram("Program nije unesen");
        $predmet->setBodovi(8);
        $predmet->setSemRedovni(2);
        $predmet->setSemIzvanredni(3);
        $predmet->setIzborni(array("ne"));
        
        //$manager->persist($predmet);

        //$manager->flush();
    }
}

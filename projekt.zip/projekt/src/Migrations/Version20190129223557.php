<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190129223557 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE upisi (id INT AUTO_INCREMENT NOT NULL, student_id_id INT NOT NULL, predmet_id_id INT NOT NULL, status VARCHAR(64) NOT NULL, INDEX IDX_EB553B58F773E7CA (student_id_id), INDEX IDX_EB553B58EDC05461 (predmet_id_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE upisi ADD CONSTRAINT FK_EB553B58F773E7CA FOREIGN KEY (student_id_id) REFERENCES korisnici (id)');
        $this->addSql('ALTER TABLE upisi ADD CONSTRAINT FK_EB553B58EDC05461 FOREIGN KEY (predmet_id_id) REFERENCES predmeti (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP TABLE upisi');
    }
}

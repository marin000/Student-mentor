<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\UpisiRepository")
 */
class Upisi
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Korisnici")
     * @ORM\JoinColumn(nullable=false)
     */
    private $student_id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Predmeti")
     * @ORM\JoinColumn(nullable=false)
     */
    private $predmet_id;

    /**
     * @ORM\Column(type="string", length=64)
     */
    private $status;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getStudentId(): ?Korisnici
    {
        return $this->student_id;
    }

    public function setStudentId(?Korisnici $student_id): self
    {
        $this->student_id = $student_id;

        return $this;
    }

    public function getPredmetId(): ?Predmeti
    {
        return $this->predmet_id;
    }

    public function setPredmetId(?Predmeti $predmet_id): self
    {
        $this->predmet_id = $predmet_id;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }
}
